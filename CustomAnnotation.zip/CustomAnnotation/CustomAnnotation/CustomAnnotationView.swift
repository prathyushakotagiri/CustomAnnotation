//
//  CustomAnnotationView.swift
//  CustomAnnotation
//
//  Created by Prathyusha kotagiri on 10/23/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

import UIKit
import MapKit

class CustomAnnotationView: MKAnnotationView {
    
    var map:MKMapView!
    var calloutView:UIImageView!

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    
    // Defaults to NO. Becomes YES when tapped/clicked on in the map view.
    override func setSelected(selected: Bool, animated: Bool){
        
        super.setSelected(selected, animated: animated)
        
        let ann:Annotation = self.annotation as! Annotation
        
        if(selected){
            
            if(ann.locationType == "apartment"){
                
                let img:UIImageView = UIImageView()
                img.frame = CGRectMake(4, 4, 120, 52)
                img.image = UIImage(named: "restaurant.png")
                
                self.calloutView = UIImageView(image: UIImage(named:"mapPopup.png"))
                calloutView.addSubview(img)
            }
            else
            {
               drawOuterView()
            }
            
            
            self.calloutView.frame = CGRectMake(-45, -65, 0, 0)
            self.calloutView.sizeToFit()
            
            animateCalloutAppearance()
            
            self.addSubview(self.calloutView)
            
            self.map.setCenterCoordinate(ann.coordinate, animated: true)
            
        }else{
            //Remove your custom view...
            calloutView.removeFromSuperview()
        }
    }

    //MARK: Custom Annottaion View
    func drawOuterView(){
        
        let ann:Annotation = self.annotation as! Annotation

        let contentWidth:CGFloat = 118.0
        let contentPad:CGFloat = 5.0
        
        self.calloutView = UIImageView(image: UIImage(named:"mapPopup.png"))
        
        let titleLabel:UILabel = UILabel(frame: CGRectMake(contentPad, 1.0, contentWidth, 21.0))
        titleLabel.text = ann.title
        titleLabel.backgroundColor = UIColor.clearColor()
        titleLabel.numberOfLines = 2
        titleLabel.font = UIFont(name:"Helvetica-Bold", size: 11.0)
        calloutView.addSubview(titleLabel)
        
        let descriptionLabel:UILabel = UILabel(frame: CGRectMake(contentPad, 16.0, contentWidth-5, 30.0))
        descriptionLabel.numberOfLines = 2
        descriptionLabel.backgroundColor = UIColor.clearColor()
        descriptionLabel.font = UIFont(name:"Helvetica", size: 10.0)
        descriptionLabel.text = ann.subtitle
        calloutView.addSubview(descriptionLabel)
        
        let imageview:UIImageView = UIImageView(frame: CGRectMake(5,42,90,2))
        imageview.backgroundColor = UIColor.redColor()
        calloutView.addSubview(imageview)
        

        let distanceLabel:UILabel = UILabel(frame: CGRectMake(contentPad, 42.0, contentWidth, 18.0))
        distanceLabel.backgroundColor = UIColor.clearColor()
        distanceLabel.textColor = UIColor.redColor()
        distanceLabel.font = UIFont(name:"Helvetica", size: 10.0)
        distanceLabel.text = NSString(format: "%.2f", ann.distance!) as String
        calloutView.addSubview(distanceLabel)
    }
    
    //MARK:Animate CallOut
    func animateCalloutAppearance(){
        
        let scale:CGFloat = 0.001
        self.calloutView.transform = CGAffineTransformMake(scale, 0.0, 0.0, scale, 0, -50.0)

        
        UIView.animateWithDuration(NSTimeInterval(0.15),
            delay: NSTimeInterval(0.0),
            options: UIViewAnimationOptions.CurveEaseOut,
            animations:
            {
                let scale:CGFloat = 1.1
                self.calloutView.transform = CGAffineTransformMake(scale, 0.0, 0.0, scale, 0, 2.0)
            },
            completion:
            {
                //This code gets called when the first animation finished.
                (value: Bool ) in
                
                    UIView.animateWithDuration(NSTimeInterval(0.1),
                    delay: NSTimeInterval(0.0),
                    options: UIViewAnimationOptions.CurveEaseInOut,
                    animations:
                        {
                            let scale:CGFloat = 0.95
                            self.calloutView.transform = CGAffineTransformMake(scale, 0.0, 0.0, scale, 0, -2.0)
                        },
                        completion:
                        {
                            //This code gets called when the first animation finished.
                            (value: Bool ) in
                        
                                UIView.animateWithDuration(NSTimeInterval(0.075),
                                delay: NSTimeInterval(0.0),
                                options: UIViewAnimationOptions.CurveEaseInOut,
                                animations:
                                {
                                    let scale:CGFloat = 1
                                    self.calloutView.transform = CGAffineTransformMake(scale, 0.0, 0.0, scale, 0.0, 0.0)
                                },
                                completion:
                                {
                                    //This code gets called when the first animation finished.
                                    (value: Bool ) in
                                
                                })

                        })
                
                })
    }
    
}
