//
//  Annotation.swift
//  CustomAnnotation
//
//  Created by Prathyusha kotagiri on 10/23/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

import UIKit
import MapKit

class Annotation:NSObject, MKAnnotation {

    var coordinate:CLLocationCoordinate2D
    var title:String?
    var subtitle:String?
    var distance:Float?
    var locationType:String?
    
    init(coord:CLLocationCoordinate2D) {
        
        //super.init(coord:CLLocationCoordinate2D)
       
        self.coordinate = coord
    }
    
    func setCoordiante(newCoordinate:CLLocationCoordinate2D)->Void{
        
        coordinate = newCoordinate
    }
    
    
  }
