//
//  ViewController.swift
//  CustomAnnotation
//
//  Created by Prathyusha kotagiri on 10/23/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController,MKMapViewDelegate,CLLocationManagerDelegate {

    @IBOutlet weak var geomapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let firstAnn:Annotation = Annotation(coord: CLLocationCoordinate2DMake(37.616815,-122.389682))
        firstAnn.title = "San Francisco,USA"
        firstAnn.subtitle = "CourtyardG,CA 94128"
        firstAnn.locationType = "airport"
        firstAnn.distance = 500;
        self.geomapView.addAnnotation(firstAnn as MKAnnotation)
        
        let secondAnn:Annotation = Annotation(coord: CLLocationCoordinate2DMake(37.626815,-122.399682))
        secondAnn.title = "San Francisco,USA"
        secondAnn.subtitle = "W Area Dr,CA 94128"
        secondAnn.locationType = "apartment"
        secondAnn.distance = 5000;
        self.geomapView.addAnnotation(secondAnn as MKAnnotation)
        
        let thirdAnn:Annotation = Annotation(coord: CLLocationCoordinate2DMake(37.604287,-122.396269))
        thirdAnn.title = "Millbrae,USA"
        thirdAnn.subtitle = "765-785 Broadway,CA 94030"
        thirdAnn.locationType = "shopping"
        thirdAnn.distance = 100000;
        self.geomapView.addAnnotation(thirdAnn as MKAnnotation)

        self.geomapView.delegate = self

        
       self.geomapView.setRegion(MKCoordinateRegionMake(firstAnn.coordinate, MKCoordinateSpanMake(0.04, 0.04)), animated: true)
        
        self.geomapView.showAnnotations(self.geomapView.annotations, animated: true)
        
    }
    
    //MARK: MKMapView Delegate
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        
        if(annotation is MKUserLocation){
            return nil
        }
        
        // Handle any custom annotations.

        if(annotation is Annotation){
            
            var pinView:CustomAnnotationView?
            = mapView.dequeueReusableAnnotationViewWithIdentifier("CustomPinAnnotationView") as? CustomAnnotationView
            
            if(pinView == nil)
            {
                pinView = CustomAnnotationView(annotation:annotation, reuseIdentifier:"CustomPinAnnotationView")
                
                pinView!.canShowCallout = false
            
            }
            else{
                pinView!.annotation = annotation
            }
            
            pinView!.image = UIImage(named:"locationRed.png")
            pinView!.map = self.geomapView
        
            return pinView
        }
        
        return nil
        
}

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

